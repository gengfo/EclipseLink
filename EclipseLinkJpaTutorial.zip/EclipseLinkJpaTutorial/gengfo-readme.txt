example resource： http://www.vogella.com/articles/JavaPersistenceAPI/article.html

1. ref-libs
C:\GengFo\KP_GengFo\gengfoRef\lib-refs\eclipselink\2.1.3\eclipselink.jar
C:\GengFo\KP_GengFo\gengfoRef\lib-refs\eclipselink\2.1.3\javax.persistence_2.0.1.v201006031150.jar

2. derby db
C:\GengFo\KP_GengFo\gengfoRef\Software\DevTools\derby
C:\db-derby-10.9.1.0-bin

2.1 start server //startNetworkServer  
2.2 add table
	ij //enter 
	connect 'jdbc:derby://localhost:1527/c:\temp\db\FAQ\db;create=true';
	run below sql: 	
CREATE TABLE FIRSTTABLE
    (ID INT PRIMARY KEY,
    NAME VARCHAR(12));
INSERT INTO FIRSTTABLE VALUES 
    (10,'TEN'),(20,'TWENTY'),(30,'THIRTY');
2.3 run DerbyTest
CREATE TABLE Todo
    (
    ID  BIGINT  NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
    summary VARCHAR(12),
    description VARCHAR(12)
    );
    
    
        
 -------reference: 
 1. default schema is APP http://db.apache.org/derby/faq.html#schema_exist
 2. id generate strategy： http://blog.csdn.net/fantian830211/article/details/4544117
 
 
 
-------  deprecated ------- 
CREATE TABLE Todo
    (
    ID INT PRIMARY KEY,
    summary VARCHAR(12),
    description VARCHAR(12)
    );
    
ID  BIGINT  NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1)
   
INSERT INTO Todo VALUES 
    (10,'TEN','TEN'),(20,'TWENTY','TWENTY'),(30,'THIRTY','THIRTY');
    
    INSERT INTO Todo VALUES 
    ('TEN','TEN'),('TWENTY','TWENTY'),('THIRTY','THIRTY');
    
CREATE TABLE SEQUENCE
    (
    SEQ_COUNT INT ,
    SEQ_NAME VARCHAR(12)
    );    
    
INSERT INTO SEQUENCE VALUES 
    (10,'Todo');