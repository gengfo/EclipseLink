package gengfo.eclipselink.model;

public class Family {

}
